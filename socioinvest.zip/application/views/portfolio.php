<div class="bg-portfolio">
  <img src="<?= base_url('assets/img/bg-portfolio.png') ?>" alt="">
</div>
<div class="conatiner row d-flex justify-content-center">
  <div class="col-6 container-portfolio">
    <h5 class="h5-orange text-center" style="color:#F23029;margin-bottom:20px">PORTFOLIO KAMI</h5>
    <h2>BERSAMA MEMBANGUN NEGERI</h2>
    <p>Lihat proyek-proyek peternakan yang telah berjalan</p>
    <a href="<?= base_url('proyek') ?>" class="btn">Download (PDF, 320 Kb)</a>

  </div>
</div>