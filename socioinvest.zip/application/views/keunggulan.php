<div class="container">
  <h5 class="h5-orange text-center" style="color:#F23029">KEUNGGULAN</h5>

  <div class="keunggulan-kami" style="margin-top:-40px !important">
    <div class="keunggulan-second-side rekam-jejak proyek-header">
      <div class="row achievements achive-1">
        <div class="col-lg-4 col-md-12 col-ms-12">
          <div class="achive" style="margin-top:0px !important">
            <div class="icon"><i class="fa fa-suitcase"></i></div>
            <h2>Memberdayakan</h2>
            <p>Proyek usaha sektor pertanian, peternakan dan pangan selalu berorientasi untuk memberdayakan peternak petani lokal.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-12 col-ms-12">
          <div class="achive achive-2">
            <div class="icon"><i class="fa fa-shield"></i></div>
            <h2>Terpercaya</h2>
            <p>Proses bermitra yang mudah serta dana usaha ataupun investasi di kelola secara transparan oleh mitra yang terpercaya.</p>
          </div>
        </div>
        <div class="col-lg-4 col-md-12 col-ms-12">
          <div class="achive achive-3">
            <div class="icon"><i class="fa fa-bar-chart-o"></i></div>
            <h2>Keuntungan</h2>
            <p>Pengelolaan tepat dan pertumbuhan usaha pertanian dan peternakan menghasilkan keuntungan yang stabil.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container rekam-jejak proyek-header" style="margin-top:-60px !important">
  <div class="row achievements">
    <div class="col-lg-4 col-md-12 col-sm-12">
      <div class="achive achive-1">
        <div class="icon"><i class="fa fa-check-square-o" style="font-size:32px"></i></div>
        <h2>50+ <br>Total proyek</h2>
        <p>Lorem ipsum dolor sit amet, consec adipiscing elit. Sit nunc sollicitudin ac leo at nec cras.</p>
      </div>
    </div>  
    <div class="col-lg-4 col-md-12 col-sm-12">
      <div class="achive achive-2">
        <div class="icon"><i class="fa fa-area-chart" style="font-size:32px"></i></div>
        <h2>50jt+ <br>Investasi Terkelola</h2>
        <p>Lorem ipsum dolor sit amet, consec adipiscing elit. Sit nunc sollicitudin ac leo at nec cras.</p>
      </div>
    </div>
    <div class="col-lg-4 col-md-12 col-sm-12">
      <div class="achive achive-3">
        <div class="icon"><i class="fa fa-users" style="font-size:28px;"></i></div>
        <h2>100+ <br>Mitra Terdaftar</h2>
        <p>Lorem ipsum dolor sit amet, consec adipiscing elit. Sit nunc sollicitudin ac leo at nec cras.</p>
      </div>
    </div>
  </div>
</div>

</div>